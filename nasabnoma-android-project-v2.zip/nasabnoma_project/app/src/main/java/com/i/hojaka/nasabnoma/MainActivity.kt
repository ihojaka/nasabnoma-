
package com.i.hojaka.nasabnoma

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.ScrollView

data class Person(val name: String, val relation: String, val year: String)

class MainActivity : AppCompatActivity() {
    private val family = mutableListOf(
        Person("Бобо", "Аждод", "1900"),
        Person("Ота", "Ота", "1965"),
        Person("Мен", "Ўзим", "1995")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.parseColor("#F8F5ED"))
        }

        val title = TextView(this).apply {
            text = "🌳 Nasabnoma"
            textSize = 28f
            setTextColor(Color.parseColor("#0F4C3A"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Nasl shajarasi - oila daraxtingizni saqlang"
            textSize = 14f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        }
        root.addView(sub)

        fun refreshList(container: LinearLayout) {
            container.removeAllViews()
            family.forEach { p ->
                val card = TextView(this).apply {
                    text = "${p.relation}: ${p.name} (${p.year})"
                    textSize = 16f
                    setPadding(24, 24, 24, 24)
                    setBackgroundColor(Color.WHITE)
                    setTextColor(Color.parseColor("#0F4C3A"))
                }
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, 0, 0, 16)
                container.addView(card, lp)
            }
        }

        val listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        refreshList(listContainer)
        root.addView(listContainer)

        val inputName = EditText(this).apply { hint = "Исм, масалан: Аҳмад бобо" }
        val inputRelation = EditText(this).apply { hint = "Қариндошлик: бобо, ота, амаки..." }
        val inputYear = EditText(this).apply { hint = "Туғилган йили: 1950" }
        root.addView(inputName)
        root.addView(inputRelation)
        root.addView(inputYear)

        val btn = Button(this).apply {
            text = "Қўшиш"
            setBackgroundColor(Color.parseColor("#0F4C3A"))
            setTextColor(Color.WHITE)
        }
        btn.setOnClickListener {
            val n = inputName.text.toString()
            val r = inputRelation.text.toString()
            val y = inputYear.text.toString()
            if (n.isNotEmpty()) {
                family.add(Person(n, if (r.isEmpty()) "Қариндош" else r, if (y.isEmpty()) "???" else y))
                refreshList(listContainer)
                inputName.text.clear()
                inputRelation.text.clear()
                inputYear.text.clear()
                Toast.makeText(this, "Қўшилди: $n", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(btn)

        val info = TextView(this).apply {
            text = "\nБу v1.0. Keyingi versiyada: Rasm, qabr joyi, xarita, PDF export"
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        root.addView(info)

        scroll.addView(root)
        setContentView(scroll)
    }
}
